// This is a visual representation of the project structure
export default function ProjectStructure() {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Access Platform Project Structure</h1>

      <div className="border rounded-lg p-4 mb-4">
        <h2 className="font-semibold mb-2">Frontend (Next.js)</h2>
        <ul className="list-disc pl-6 space-y-1">
          <li>app/ - Next.js App Router</li>
          <li>components/ - Reusable UI components</li>
          <li>lib/ - Utility functions and shared logic</li>
          <li>hooks/ - Custom React hooks</li>
          <li>styles/ - Global styles and theme</li>
          <li>public/ - Static assets</li>
        </ul>
      </div>

      <div className="border rounded-lg p-4 mb-4">
        <h2 className="font-semibold mb-2">Backend (Node.js/Express)</h2>
        <ul className="list-disc pl-6 space-y-1">
          <li>api/ - API routes and controllers</li>
          <li>models/ - Database models</li>
          <li>services/ - Business logic</li>
          <li>middleware/ - Express middleware</li>
          <li>utils/ - Utility functions</li>
          <li>config/ - Configuration files</li>
        </ul>
      </div>

      <div className="border rounded-lg p-4">
        <h2 className="font-semibold mb-2">Infrastructure</h2>
        <ul className="list-disc pl-6 space-y-1">
          <li>database/ - Database setup and migrations</li>
          <li>deployment/ - Deployment scripts and configurations</li>
          <li>monitoring/ - Logging and monitoring setup</li>
          <li>security/ - Security configurations</li>
        </ul>
      </div>
    </div>
  )
}

