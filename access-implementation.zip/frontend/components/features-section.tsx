import { MessageSquare, Video, TrendingUp, Gamepad2, BookOpen, Shield, Crown } from "lucide-react"

export function FeaturesSection() {
  const features = [
    {
      icon: <MessageSquare className="h-10 w-10 text-purple-600" />,
      title: "Social Networking",
      description: "Connect with friends, share posts, and engage with a global community.",
    },
    {
      icon: <Video className="h-10 w-10 text-purple-600" />,
      title: "Live Streaming",
      description: "Go live with friends, receive gifts, and build your audience.",
    },
    {
      icon: <TrendingUp className="h-10 w-10 text-purple-600" />,
      title: "Trading Platform",
      description: "Buy and sell company shares worldwide, including Access Group shares.",
    },
    {
      icon: <Gamepad2 className="h-10 w-10 text-purple-600" />,
      title: "Casino Games",
      description: "Enjoy casino games with secure payment options for users 18+.",
    },
    {
      icon: <BookOpen className="h-10 w-10 text-purple-600" />,
      title: "E-Book Library",
      description: "Access a vast collection of digital books from around the world.",
    },
    {
      icon: <Shield className="h-10 w-10 text-purple-600" />,
      title: "Secure Verification",
      description: "Government ID and face scan verification for enhanced security.",
    },
    {
      icon: <Crown className="h-10 w-10 text-purple-600" />,
      title: "VIP Subscriptions",
      description: "Exclusive benefits and features for VIP members.",
    },
  ]

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-50 dark:bg-gray-900">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">All-in-One Platform</h2>
            <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
              Access combines the best features from multiple platforms into one seamless experience.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-12">
          {features.map((feature, index) => (
            <div
              key={index}
              className="flex flex-col items-center space-y-2 rounded-lg border p-6 bg-white dark:bg-gray-800"
            >
              {feature.icon}
              <h3 className="text-xl font-bold">{feature.title}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

