import Link from "next/link"

export default function Footer() {
  return (
    <footer className="w-full border-t bg-background">
      <div className="container flex flex-col md:flex-row items-center justify-between gap-4 py-10 px-4 md:px-6">
        <div className="flex flex-col items-center md:items-start gap-4">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl font-bold">Access</span>
          </Link>
          <p className="text-sm text-gray-500 dark:text-gray-400 text-center md:text-left">
            &copy; {new Date().getFullYear()} Access Social Media. All rights reserved.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          <div className="flex flex-col gap-2">
            <h3 className="text-sm font-medium">Platform</h3>
            <Link href="/features" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Features
            </Link>
            <Link href="/pricing" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Pricing
            </Link>
            <Link href="/about" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              About
            </Link>
          </div>
          <div className="flex flex-col gap-2">
            <h3 className="text-sm font-medium">Resources</h3>
            <Link href="/blog" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Blog
            </Link>
            <Link href="/help" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Help Center
            </Link>
            <Link href="/guides" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Guides
            </Link>
          </div>
          <div className="flex flex-col gap-2">
            <h3 className="text-sm font-medium">Legal</h3>
            <Link href="/privacy" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Privacy
            </Link>
            <Link href="/terms" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Terms
            </Link>
            <Link href="/cookies" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Cookies
            </Link>
          </div>
          <div className="flex flex-col gap-2">
            <h3 className="text-sm font-medium">Contact</h3>
            <Link href="/contact" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Contact Us
            </Link>
            <Link href="/support" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Support
            </Link>
            <Link href="/feedback" className="text-sm text-gray-500 dark:text-gray-400 hover:underline">
              Feedback
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

