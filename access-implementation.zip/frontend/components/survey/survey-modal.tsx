"use client"

import { useState, useEffect } from "react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/hooks/use-toast"

interface SurveyQuestion {
  id: string
  type: "multiple_choice" | "rating" | "open_ended" | "likert_scale" | "yes_no"
  text: string
  options?: string[]
  required: boolean
}

interface SurveyProps {
  id: string
  title: string
  description: string
  questions: SurveyQuestion[]
  isOpen: boolean
  onClose: () => void
  onSubmit: (responses: any) => Promise<void>
}

export function SurveyModal({ id, title, description, questions, isOpen, onClose, onSubmit }: SurveyProps) {
  const [responses, setResponses] = useState<Record<string, any>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const { toast } = useToast()

  // Reset responses when survey changes
  useEffect(() => {
    setResponses({})
    setCurrentStep(0)
  }, [id])

  const handleInputChange = (questionId: string, value: any) => {
    setResponses((prev) => ({
      ...prev,
      [questionId]: value,
    }))
  }

  const isCurrentQuestionAnswered = () => {
    const currentQuestion = questions[currentStep]
    if (!currentQuestion.required) return true
    return responses[currentQuestion.id] !== undefined && responses[currentQuestion.id] !== ""
  }

  const handleNext = () => {
    if (isCurrentQuestionAnswered()) {
      setCurrentStep((prev) => Math.min(prev + 1, questions.length - 1))
    } else {
      toast({
        title: "Required Question",
        description: "Please answer this question before proceeding.",
        variant: "destructive",
      })
    }
  }

  const handlePrevious = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 0))
  }

  const handleSubmit = async () => {
    // Check if all required questions are answered
    const unansweredRequired = questions
      .filter((q) => q.required)
      .filter((q) => responses[q.id] === undefined || responses[q.id] === "")

    if (unansweredRequired.length > 0) {
      toast({
        title: "Required Questions",
        description: "Please answer all required questions before submitting.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Format responses for submission
      const formattedResponses = Object.entries(responses).map(([questionId, answer]) => ({
        questionId,
        answer,
      }))

      await onSubmit(formattedResponses)

      toast({
        title: "Survey Submitted",
        description: "Thank you for your feedback!",
      })

      onClose()
    } catch (error) {
      console.error("Error submitting survey:", error)
      toast({
        title: "Submission Error",
        description: "There was an error submitting your survey. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const renderQuestion = (question: SurveyQuestion) => {
    switch (question.type) {
      case "multiple_choice":
        return (
          <RadioGroup
            value={responses[question.id] || ""}
            onValueChange={(value) => handleInputChange(question.id, value)}
          >
            {question.options?.map((option) => (
              <div key={option} className="flex items-center space-x-2">
                <RadioGroupItem value={option} id={`${question.id}-${option}`} />
                <Label htmlFor={`${question.id}-${option}`}>{option}</Label>
              </div>
            ))}
          </RadioGroup>
        )

      case "rating":
        return (
          <div className="space-y-4">
            <Slider
              value={[responses[question.id] || 0]}
              min={0}
              max={10}
              step={1}
              onValueChange={(value) => handleInputChange(question.id, value[0])}
            />
            <div className="flex justify-between">
              <span>0</span>
              <span>5</span>
              <span>10</span>
            </div>
            <div className="text-center">Selected: {responses[question.id] || 0}</div>
          </div>
        )

      case "open_ended":
        return (
          <Textarea
            value={responses[question.id] || ""}
            onChange={(e) => handleInputChange(question.id, e.target.value)}
            placeholder="Type your answer here..."
            className="min-h-[100px]"
          />
        )

      case "yes_no":
        return (
          <RadioGroup
            value={responses[question.id] || ""}
            onValueChange={(value) => handleInputChange(question.id, value)}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="yes" id={`${question.id}-yes`} />
              <Label htmlFor={`${question.id}-yes`}>Yes</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="no" id={`${question.id}-no`} />
              <Label htmlFor={`${question.id}-no`}>No</Label>
            </div>
          </RadioGroup>
        )

      case "likert_scale":
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-5 gap-2 text-center">
              <div>Strongly Disagree</div>
              <div>Disagree</div>
              <div>Neutral</div>
              <div>Agree</div>
              <div>Strongly Agree</div>
            </div>
            <RadioGroup
              value={responses[question.id] || ""}
              onValueChange={(value) => handleInputChange(question.id, value)}
              className="grid grid-cols-5 gap-2"
            >
              {["1", "2", "3", "4", "5"].map((value) => (
                <div key={value} className="flex justify-center">
                  <RadioGroupItem value={value} id={`${question.id}-${value}`} />
                </div>
              ))}
            </RadioGroup>
          </div>
        )

      default:
        return null
    }
  }

  const currentQuestion = questions[currentStep]

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        {questions.length > 0 && (
          <div className="space-y-4 py-4">
            <div className="text-sm text-muted-foreground">
              Question {currentStep + 1} of {questions.length}
              {currentQuestion.required && <span className="text-red-500 ml-1">*</span>}
            </div>

            <div className="font-medium">{currentQuestion.text}</div>

            {renderQuestion(currentQuestion)}
          </div>
        )}

        <DialogFooter className="flex justify-between">
          <div>
            {currentStep > 0 && (
              <Button variant="outline" onClick={handlePrevious} disabled={isSubmitting}>
                Previous
              </Button>
            )}
          </div>
          <div>
            {currentStep < questions.length - 1 ? (
              <Button onClick={handleNext} disabled={isSubmitting || !isCurrentQuestionAnswered()}>
                Next
              </Button>
            ) : (
              <Button onClick={handleSubmit} disabled={isSubmitting}>
                {isSubmitting ? "Submitting..." : "Submit"}
              </Button>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

