"use client"

import { useState, useEffect } from "react"
import { SurveyModal } from "./survey-modal"
import { useToast } from "@/hooks/use-toast"

interface SurveyTriggerProps {
  userId: string
}

export function SurveyTrigger({ userId }: SurveyTriggerProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [survey, setSurvey] = useState<any>(null)
  const [hasChecked, setHasChecked] = useState(false)
  const { toast } = useToast()

  // Check for available surveys
  useEffect(() => {
    const checkForSurveys = async () => {
      if (hasChecked || !userId) return

      try {
        // In a real implementation, this would check for available surveys for this user
        const response = await fetch(`/api/automation/surveys/available?userId=${userId}`)

        if (response.ok) {
          const data = await response.json()

          if (data.survey) {
            setSurvey(data.survey)

            // Wait a few seconds before showing the survey
            setTimeout(() => {
              setIsOpen(true)
            }, 5000)
          }
        }
      } catch (error) {
        console.error("Error checking for surveys:", error)
      } finally {
        setHasChecked(true)
      }
    }

    checkForSurveys()
  }, [userId, hasChecked])

  const handleSubmit = async (responses: any) => {
    try {
      const response = await fetch("/api/automation/feedback/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          surveyId: survey.id,
          userId,
          responses,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to submit feedback")
      }

      // Reset survey state
      setSurvey(null)
      setHasChecked(false)
    } catch (error) {
      console.error("Error submitting feedback:", error)
      throw error
    }
  }

  if (!survey) return null

  return (
    <SurveyModal
      id={survey.id}
      title={survey.title}
      description={survey.description}
      questions={survey.questions}
      isOpen={isOpen}
      onClose={() => setIsOpen(false)}
      onSubmit={handleSubmit}
    />
  )
}

