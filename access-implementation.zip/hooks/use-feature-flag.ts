"use client"

import { useState, useEffect } from "react"
import { isFeatureEnabled } from "@/lib/feature-flags"

export function useFeatureFlag(featureKey: string): boolean {
  const [isEnabled, setIsEnabled] = useState(false)
  const [userId, setUserId] = useState<string | undefined>(undefined)

  useEffect(() => {
    // In a real app, you would get the user ID from your auth system
    const fetchUserId = async () => {
      try {
        // This is a placeholder - replace with your actual auth logic
        const response = await fetch("/api/auth/me")
        if (response.ok) {
          const data = await response.json()
          setUserId(data.id)
        }
      } catch (error) {
        console.error("Error fetching user:", error)
      }
    }

    fetchUserId()
  }, [])

  useEffect(() => {
    // Check if the feature is enabled whenever userId changes
    setIsEnabled(isFeatureEnabled(featureKey, userId))

    // In a real app, you might want to subscribe to real-time updates
    // for feature flags, especially if they can change while the app is running
  }, [featureKey, userId])

  return isEnabled
}

