import { NextResponse } from "next/server"
import { automationController } from "@/automation/automation-controller"
import { logger } from "@/lib/monitoring/logger"

export async function POST() {
  try {
    const success = await automationController.initialize()

    if (success) {
      return NextResponse.json({
        success: true,
        message: "Automation systems initialized successfully",
      })
    } else {
      return NextResponse.json(
        {
          success: false,
          message: "Failed to initialize automation systems",
        },
        { status: 500 },
      )
    }
  } catch (error) {
    logger.error("Error initializing automation systems", error as Error)

    return NextResponse.json(
      {
        success: false,
        message: "An error occurred while initializing automation systems",
      },
      { status: 500 },
    )
  }
}

