import { NextResponse } from "next/server"
import { automationController } from "@/automation/automation-controller"
import { logger } from "@/lib/monitoring/logger"

export async function POST() {
  try {
    const success = await automationController.runWeeklyEnhancementGeneration()

    if (success) {
      return NextResponse.json({
        success: true,
        message: "Weekly enhancement generation completed successfully",
      })
    } else {
      return NextResponse.json(
        {
          success: false,
          message: "Failed to run weekly enhancement generation",
        },
        { status: 500 },
      )
    }
  } catch (error) {
    logger.error("Error running weekly enhancement generation", error as Error)

    return NextResponse.json(
      {
        success: false,
        message: "An error occurred while running weekly enhancement generation",
      },
      { status: 500 },
    )
  }
}

