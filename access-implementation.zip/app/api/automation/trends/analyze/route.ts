import { NextResponse } from "next/server"
import { automationController } from "@/automation/automation-controller"
import { logger } from "@/lib/monitoring/logger"

export async function POST() {
  try {
    const success = await automationController.runDailyTrendAnalysis()

    if (success) {
      return NextResponse.json({
        success: true,
        message: "Daily trend analysis completed successfully",
      })
    } else {
      return NextResponse.json(
        {
          success: false,
          message: "Failed to run daily trend analysis",
        },
        { status: 500 },
      )
    }
  } catch (error) {
    logger.error("Error running daily trend analysis", error as Error)

    return NextResponse.json(
      {
        success: false,
        message: "An error occurred while running daily trend analysis",
      },
      { status: 500 },
    )
  }
}

