import { AutomationDashboard } from "@/components/admin/automation-dashboard"

export default function AutomationPage() {
  return <AutomationDashboard />
}

