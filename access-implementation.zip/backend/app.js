// Add this near the top of your app.js file
const { initializeAutomation } = require("./automation-init")

// Add this after your app is initialized but before it starts listening
// Initialize automation systems
if (process.env.NODE_ENV === "production") {
  initializeAutomation().catch((error) => {
    console.error("Failed to initialize automation systems:", error)
  })
}

