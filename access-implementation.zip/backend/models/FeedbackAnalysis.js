const mongoose = require("mongoose")

const FeatureRequestSchema = new mongoose.Schema({
  feature: {
    type: String,
    required: true,
  },
  count: {
    type: Number,
    required: true,
  },
  priority: {
    type: Number,
    required: true,
    min: 1,
    max: 10,
  },
})

const ImprovementSuggestionSchema = new mongoose.Schema({
  area: {
    type: String,
    required: true,
  },
  suggestion: {
    type: String,
    required: true,
  },
  impact: {
    type: String,
    enum: ["high", "medium", "low"],
    required: true,
  },
})

const FeedbackAnalysisSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
    unique: true,
  },
  surveyId: {
    type: String,
    required: true,
  },
  totalResponses: {
    type: Number,
    required: true,
  },
  sentimentScore: {
    type: Number,
    required: true,
    min: -1,
    max: 1,
  },
  topThemes: [String],
  featureRequests: [FeatureRequestSchema],
  improvementSuggestions: [ImprovementSuggestionSchema],
  summary: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

module.exports = mongoose.model("FeedbackAnalysis", FeedbackAnalysisSchema)

