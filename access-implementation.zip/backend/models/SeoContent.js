const mongoose = require("mongoose")

const SeoContentSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
    unique: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  keywords: [String],
  content: {
    type: String,
    required: true,
  },
  slug: {
    type: String,
    required: true,
    unique: true,
  },
  trend: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  publishedAt: Date,
  status: {
    type: String,
    enum: ["draft", "published", "archived"],
    default: "draft",
  },
})

module.exports = mongoose.model("SeoContent", SeoContentSchema)

