const mongoose = require("mongoose")

const LeadSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
    unique: true,
  },
  email: {
    type: String,
    required: true,
  },
  name: String,
  source: {
    type: String,
    required: true,
  },
  sourceDetails: {
    type: Map,
    of: mongoose.Schema.Types.Mixed,
  },
  score: {
    type: Number,
    required: true,
  },
  status: {
    type: String,
    enum: ["new", "nurturing", "qualified", "converted", "lost"],
    default: "new",
  },
  tags: [String],
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
  lastContactedAt: Date,
  conversionProbability: Number,
})

module.exports = mongoose.model("Lead", LeadSchema)

