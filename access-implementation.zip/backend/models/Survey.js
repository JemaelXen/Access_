const mongoose = require("mongoose")

const SurveyQuestionSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
  },
  type: {
    type: String,
    enum: ["multiple_choice", "rating", "open_ended", "likert_scale", "yes_no"],
    required: true,
  },
  text: {
    type: String,
    required: true,
  },
  options: [String],
  required: {
    type: Boolean,
    default: true,
  },
})

const SurveySchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
    unique: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  type: {
    type: String,
    enum: ["general_feedback", "feature_specific", "user_satisfaction", "feature_request", "usability"],
    required: true,
  },
  questions: [SurveyQuestionSchema],
  targetUserSegment: String,
  createdAt: {
    type: Date,
    default: Date.now,
  },
  expiresAt: {
    type: Date,
    required: true,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
})

module.exports = mongoose.model("Survey", SurveySchema)

