const mongoose = require("mongoose")

const EnhancementSuggestionSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
    unique: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  area: {
    type: String,
    enum: ["ui", "feature", "performance", "security", "other"],
    required: true,
  },
  priority: {
    type: String,
    enum: ["critical", "high", "medium", "low"],
    required: true,
  },
  impact: {
    type: String,
    enum: ["high", "medium", "low"],
    required: true,
  },
  effort: {
    type: String,
    enum: ["high", "medium", "low"],
    required: true,
  },
  implementationSteps: [String],
  sourceFeedbackIds: [String],
  status: {
    type: String,
    enum: ["pending", "approved", "rejected", "implemented"],
    default: "pending",
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

module.exports = mongoose.model("EnhancementSuggestion", EnhancementSuggestionSchema)

