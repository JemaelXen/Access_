const mongoose = require("mongoose")

const ResponseItemSchema = new mongoose.Schema({
  questionId: {
    type: String,
    required: true,
  },
  answer: {
    type: mongoose.Schema.Types.Mixed,
    required: true,
  },
})

const FeedbackResponseSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true,
    unique: true,
  },
  surveyId: {
    type: String,
    required: true,
  },
  userId: {
    type: String,
    required: true,
  },
  responses: [ResponseItemSchema],
  submittedAt: {
    type: Date,
    default: Date.now,
  },
})

module.exports = mongoose.model("FeedbackResponse", FeedbackResponseSchema)

