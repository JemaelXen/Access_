const cron = require("node-cron")
const { automationController } = require("./automation/automation-controller")

// Initialize automation systems
async function initializeAutomation() {
  try {
    console.log("Initializing automation systems...")

    // Initialize automation controller
    await automationController.initialize()

    // Schedule daily trend analysis at 1 AM
    cron.schedule("0 1 * * *", async () => {
      console.log("Running daily trend analysis...")
      await automationController.runDailyTrendAnalysis()
    })

    // Schedule weekly enhancement generation at 2 AM on Sundays
    cron.schedule("0 2 * * 0", async () => {
      console.log("Running weekly enhancement generation...")
      await automationController.runWeeklyEnhancementGeneration()
    })

    console.log("Automation systems initialized successfully")
  } catch (error) {
    console.error("Failed to initialize automation systems:", error)
  }
}

module.exports = { initializeAutomation }

