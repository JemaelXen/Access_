const User = require("../../models/User")
const Post = require("../../models/Post")
const Transaction = require("../../models/Transaction")

const getAdminStats = async (req, res) => {
  try {
    // Get total users
    const totalUsers = await User.countDocuments()

    // Get pending KYC requests
    const pendingKyc = await User.countDocuments({ kycStatus: "pending" })

    // Get total posts
    const totalPosts = await Post.countDocuments()

    // Get flagged content
    const flaggedContent = await Post.countDocuments({ isFlagged: true })

    // Get total revenue
    const transactions = await Transaction.find()
    const revenue = transactions.reduce((total, transaction) => {
      return total + (transaction.amount || 0)
    }, 0)

    res.status(200).json({
      totalUsers,
      pendingKyc,
      totalPosts,
      flaggedContent,
      revenue,
    })
  } catch (error) {
    console.error("Error fetching admin stats:", error)
    res.status(500).json({ message: "Failed to fetch admin statistics" })
  }
}

module.exports = { getAdminStats }

