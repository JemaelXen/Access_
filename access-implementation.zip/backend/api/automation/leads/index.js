const Lead = require("../../../models/Lead")
const { leadGenerationEngine } = require("../../../automation/leads/lead-generation-engine")

// Get all leads
const getAllLeads = async (req, res) => {
  try {
    const { status, minScore } = req.query

    const query = {}

    if (status) {
      query.status = status
    }

    if (minScore) {
      query.score = { $gte: Number.parseInt(minScore) }
    }

    const leads = await Lead.find(query).sort({ score: -1 })

    res.status(200).json(leads)
  } catch (error) {
    console.error("Error fetching leads:", error)
    res.status(500).json({ message: "Failed to fetch leads" })
  }
}

// Generate leads from trends
const generateLeadsFromTrends = async (req, res) => {
  try {
    const { trends } = req.body

    if (!trends || !Array.isArray(trends)) {
      return res.status(400).json({ message: "Trends array is required" })
    }

    const leads = await leadGenerationEngine.generateLeadsFromTrends(trends)

    res.status(201).json({
      message: "Leads generated successfully",
      count: leads.length,
      leads,
    })
  } catch (error) {
    console.error("Error generating leads:", error)
    res.status(500).json({ message: "Failed to generate leads" })
  }
}

// Create nurturing campaigns
const createNurturingCampaigns = async (req, res) => {
  try {
    const { leadIds } = req.body

    if (!leadIds || !Array.isArray(leadIds)) {
      return res.status(400).json({ message: "Lead IDs array is required" })
    }

    // Get leads
    const leads = await Lead.find({
      id: { $in: leadIds },
    })

    if (leads.length === 0) {
      return res.status(404).json({ message: "No leads found" })
    }

    const success = await leadGenerationEngine.createNurturingCampaigns(leads)

    if (success) {
      res.status(200).json({
        message: "Nurturing campaigns created successfully",
        leadCount: leads.length,
      })
    } else {
      res.status(500).json({ message: "Failed to create nurturing campaigns" })
    }
  } catch (error) {
    console.error("Error creating nurturing campaigns:", error)
    res.status(500).json({ message: "Failed to create nurturing campaigns" })
  }
}

module.exports = {
  getAllLeads,
  generateLeadsFromTrends,
  createNurturingCampaigns,
}

