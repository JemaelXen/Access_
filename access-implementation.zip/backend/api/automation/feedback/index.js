const FeedbackResponse = require("../../../models/FeedbackResponse")
const { feedbackAnalyzer } = require("../../../automation/feedback/feedback-analyzer")
const FeedbackAnalysis = require("../../../models/FeedbackAnalysis") // Import FeedbackAnalysis model

// Submit feedback response
const submitFeedback = async (req, res) => {
  try {
    const { surveyId, userId, responses } = req.body

    if (!surveyId || !userId || !responses) {
      return res.status(400).json({ message: "Survey ID, user ID, and responses are required" })
    }

    const feedbackResponse = new FeedbackResponse({
      id: `response_${Date.now()}_${userId}`,
      surveyId,
      userId,
      responses,
      submittedAt: new Date(),
    })

    await feedbackResponse.save()

    res.status(201).json({
      message: "Feedback submitted successfully",
      responseId: feedbackResponse.id,
    })
  } catch (error) {
    console.error("Error submitting feedback:", error)
    res.status(500).json({ message: "Failed to submit feedback" })
  }
}

// Analyze feedback for a survey
const analyzeFeedback = async (req, res) => {
  try {
    const { surveyId } = req.params

    if (!surveyId) {
      return res.status(400).json({ message: "Survey ID is required" })
    }

    const analysis = await feedbackAnalyzer.analyzeFeedback(surveyId)

    res.status(200).json(analysis)
  } catch (error) {
    console.error("Error analyzing feedback:", error)
    res.status(500).json({ message: "Failed to analyze feedback" })
  }
}

// Get feedback analysis for a survey
const getFeedbackAnalysis = async (req, res) => {
  try {
    const { surveyId } = req.params

    const analysis = await FeedbackAnalysis.findOne({ surveyId })

    if (!analysis) {
      return res.status(404).json({ message: "Feedback analysis not found" })
    }

    res.status(200).json(analysis)
  } catch (error) {
    console.error("Error fetching feedback analysis:", error)
    res.status(500).json({ message: "Failed to fetch feedback analysis" })
  }
}

module.exports = {
  submitFeedback,
  analyzeFeedback,
  getFeedbackAnalysis,
}

