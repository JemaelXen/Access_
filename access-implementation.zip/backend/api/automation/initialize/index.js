const { automationController } = require("../../../automation/automation-controller")

// Initialize automation systems
const initializeAutomation = async (req, res) => {
  try {
    const success = await automationController.initialize()

    if (success) {
      res.status(200).json({
        message: "Automation systems initialized successfully",
      })
    } else {
      res.status(500).json({
        message: "Failed to initialize automation systems",
      })
    }
  } catch (error) {
    console.error("Error initializing automation systems:", error)
    res.status(500).json({
      message: "An error occurred while initializing automation systems",
    })
  }
}

module.exports = {
  initializeAutomation,
}

