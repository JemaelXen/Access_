const EnhancementSuggestion = require("../../../models/EnhancementSuggestion")
const { aiEnhancementEngine } = require("../../../automation/enhancement/ai-enhancement-engine")
const FeedbackAnalysis = require("../../../models/FeedbackAnalysis") // Import FeedbackAnalysis model

// Get all enhancement suggestions
const getAllEnhancements = async (req, res) => {
  try {
    const { status } = req.query

    const query = status ? { status } : {}

    const enhancements = await EnhancementSuggestion.find(query).sort({ createdAt: -1 })

    res.status(200).json(enhancements)
  } catch (error) {
    console.error("Error fetching enhancements:", error)
    res.status(500).json({ message: "Failed to fetch enhancements" })
  }
}

// Generate enhancement suggestions
const generateEnhancements = async (req, res) => {
  try {
    const { feedbackAnalysisIds } = req.body

    if (!feedbackAnalysisIds || !Array.isArray(feedbackAnalysisIds)) {
      return res.status(400).json({ message: "Feedback analysis IDs array is required" })
    }

    // Get feedback analyses
    const feedbackAnalyses = await FeedbackAnalysis.find({
      _id: { $in: feedbackAnalysisIds }, // Changed id to _id to match MongoDB's default id field
    })

    if (feedbackAnalyses.length === 0) {
      return res.status(404).json({ message: "No feedback analyses found" })
    }

    const suggestions = await aiEnhancementEngine.generateEnhancements(feedbackAnalyses)

    res.status(201).json(suggestions)
  } catch (error) {
    console.error("Error generating enhancements:", error)
    res.status(500).json({ message: "Failed to generate enhancements" })
  }
}

// Update enhancement status
const updateEnhancementStatus = async (req, res) => {
  try {
    const { id } = req.params
    const { status } = req.body

    if (!status) {
      return res.status(400).json({ message: "Status is required" })
    }

    const enhancement = await EnhancementSuggestion.findOne({ _id: id }) // Changed id to _id to match MongoDB's default id field

    if (!enhancement) {
      return res.status(404).json({ message: "Enhancement suggestion not found" })
    }

    enhancement.status = status
    enhancement.updatedAt = new Date()

    await enhancement.save()

    // If status is "approved", trigger implementation
    if (status === "approved") {
      await aiEnhancementEngine.triggerImplementation(id)
    }

    res.status(200).json({
      message: "Enhancement status updated successfully",
      enhancement,
    })
  } catch (error) {
    console.error("Error updating enhancement status:", error)
    res.status(500).json({ message: "Failed to update enhancement status" })
  }
}

module.exports = {
  getAllEnhancements,
  generateEnhancements,
  updateEnhancementStatus,
}

