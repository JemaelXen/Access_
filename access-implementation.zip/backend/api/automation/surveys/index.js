const Survey = require("../../../models/Survey")
const { surveyGenerator } = require("../../../automation/feedback/survey-generator")

// Get all surveys
const getAllSurveys = async (req, res) => {
  try {
    const surveys = await Survey.find().sort({ createdAt: -1 })
    res.status(200).json(surveys)
  } catch (error) {
    console.error("Error fetching surveys:", error)
    res.status(500).json({ message: "Failed to fetch surveys" })
  }
}

// Get a single survey by ID
const getSurveyById = async (req, res) => {
  try {
    const survey = await Survey.findOne({ id: req.params.id })

    if (!survey) {
      return res.status(404).json({ message: "Survey not found" })
    }

    res.status(200).json(survey)
  } catch (error) {
    console.error("Error fetching survey:", error)
    res.status(500).json({ message: "Failed to fetch survey" })
  }
}

// Generate a new survey
const generateSurvey = async (req, res) => {
  try {
    const { surveyType, recentFeatures, userSegment } = req.body

    if (!surveyType || !recentFeatures) {
      return res.status(400).json({ message: "Survey type and recent features are required" })
    }

    const survey = await surveyGenerator.generateWeeklySurvey(surveyType, recentFeatures, userSegment)

    res.status(201).json(survey)
  } catch (error) {
    console.error("Error generating survey:", error)
    res.status(500).json({ message: "Failed to generate survey" })
  }
}

module.exports = {
  getAllSurveys,
  getSurveyById,
  generateSurvey,
}

