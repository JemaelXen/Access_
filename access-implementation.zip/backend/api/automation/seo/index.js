const SeoContent = require("../../../models/SeoContent")
const { seoAutomationEngine } = require("../../../automation/seo/seo-automation-engine")

// Get all SEO content
const getAllSeoContent = async (req, res) => {
  try {
    const { status } = req.query

    const query = status ? { status } : {}

    const content = await SeoContent.find(query).sort({ createdAt: -1 })

    res.status(200).json(content)
  } catch (error) {
    console.error("Error fetching SEO content:", error)
    res.status(500).json({ message: "Failed to fetch SEO content" })
  }
}

// Generate SEO content from trends
const generateSeoContent = async (req, res) => {
  try {
    const { trends } = req.body

    if (!trends || !Array.isArray(trends)) {
      return res.status(400).json({ message: "Trends array is required" })
    }

    const content = await seoAutomationEngine.generateSeoContent(trends)

    res.status(201).json({
      message: "SEO content generated successfully",
      count: content.length,
      content,
    })
  } catch (error) {
    console.error("Error generating SEO content:", error)
    res.status(500).json({ message: "Failed to generate SEO content" })
  }
}

// Publish SEO content
const publishSeoContent = async (req, res) => {
  try {
    const { id } = req.params

    const success = await seoAutomationEngine.publishContent(id)

    if (success) {
      res.status(200).json({ message: "SEO content published successfully" })
    } else {
      res.status(500).json({ message: "Failed to publish SEO content" })
    }
  } catch (error) {
    console.error("Error publishing SEO content:", error)
    res.status(500).json({ message: "Failed to publish SEO content" })
  }
}

// Analyze SEO performance
const analyzeSeoPerformance = async (req, res) => {
  try {
    const performance = await seoAutomationEngine.analyzeSeoPerformance()

    res.status(200).json(performance)
  } catch (error) {
    console.error("Error analyzing SEO performance:", error)
    res.status(500).json({ message: "Failed to analyze SEO performance" })
  }
}

module.exports = {
  getAllSeoContent,
  generateSeoContent,
  publishSeoContent,
  analyzeSeoPerformance,
}

