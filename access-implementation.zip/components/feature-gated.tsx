"use client"

import type { ReactNode } from "react"
import { useFeatureFlag } from "@/hooks/use-feature-flag"

interface FeatureGatedProps {
  featureKey: string
  children: ReactNode
  fallback?: ReactNode
}

export function FeatureGated({ featureKey, children, fallback = null }: FeatureGatedProps) {
  const isEnabled = useFeatureFlag(featureKey)

  if (isEnabled) {
    return <>{children}</>
  }

  return <>{fallback}</>
}

