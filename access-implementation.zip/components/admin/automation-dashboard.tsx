"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Users, TrendingUp, Bot, Mail, CheckCircle, Clock } from "lucide-react"

export function AutomationDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [stats, setStats] = useState({
    surveys: {
      total: 0,
      completed: 0,
      pending: 0,
      responseRate: 0,
    },
    enhancements: {
      total: 0,
      implemented: 0,
      pending: 0,
      rejected: 0,
    },
    leads: {
      total: 0,
      converted: 0,
      nurturing: 0,
      conversionRate: 0,
    },
    seo: {
      totalContent: 0,
      published: 0,
      draft: 0,
      averageViews: 0,
    },
  })

  useEffect(() => {
    const fetchAutomationStats = async () => {
      try {
        setIsLoading(true)
        // In a real app, you would fetch this data from your API

        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Mock data
        setStats({
          surveys: {
            total: 24,
            completed: 18,
            pending: 6,
            responseRate: 0.68,
          },
          enhancements: {
            total: 42,
            implemented: 28,
            pending: 10,
            rejected: 4,
          },
          leads: {
            total: 1250,
            converted: 320,
            nurturing: 750,
            conversionRate: 0.256,
          },
          seo: {
            totalContent: 86,
            published: 72,
            draft: 14,
            averageViews: 1250,
          },
        })

        setIsLoading(false)
      } catch (error) {
        setError("Failed to load automation statistics")
        console.error(error)
        setIsLoading(false)
      }
    }

    fetchAutomationStats()
  }, [])

  const enhancementData = [
    { name: "Implemented", value: stats.enhancements.implemented, color: "#4ade80" },
    { name: "Pending", value: stats.enhancements.pending, color: "#facc15" },
    { name: "Rejected", value: stats.enhancements.rejected, color: "#f87171" },
  ]

  const leadData = [
    { name: "Jan", leads: 150, conversions: 35 },
    { name: "Feb", leads: 220, conversions: 48 },
    { name: "Mar", leads: 180, conversions: 42 },
    { name: "Apr", leads: 250, conversions: 65 },
    { name: "May", leads: 310, conversions: 82 },
    { name: "Jun", leads: 290, conversions: 78 },
  ]

  if (isLoading) {
    return <div className="flex items-center justify-center h-screen">Loading automation dashboard...</div>
  }

  if (error) {
    return <div className="flex items-center justify-center h-screen text-destructive">{error}</div>
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Automation Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              Survey Responses
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.surveys.total}</div>
            <p className="text-xs text-muted-foreground">{stats.surveys.responseRate * 100}% response rate</p>
            <Progress className="mt-2" value={stats.surveys.responseRate * 100} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Bot className="h-4 w-4 text-muted-foreground" />
              AI Enhancements
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.enhancements.total}</div>
            <p className="text-xs text-muted-foreground">{stats.enhancements.implemented} implemented</p>
            <Progress className="mt-2" value={(stats.enhancements.implemented / stats.enhancements.total) * 100} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              Generated Leads
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.leads.total}</div>
            <p className="text-xs text-muted-foreground">{stats.leads.conversionRate * 100}% conversion rate</p>
            <Progress className="mt-2" value={stats.leads.conversionRate * 100} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              SEO Content
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.seo.totalContent}</div>
            <p className="text-xs text-muted-foreground">{stats.seo.averageViews} avg. views per content</p>
            <Progress className="mt-2" value={(stats.seo.published / stats.seo.totalContent) * 100} />
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="feedback">User Feedback</TabsTrigger>
          <TabsTrigger value="enhancements">AI Enhancements</TabsTrigger>
          <TabsTrigger value="leads">Lead Generation</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Enhancement Status</CardTitle>
                <CardDescription>Distribution of AI-suggested enhancements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={enhancementData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {enhancementData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lead Generation Performance</CardTitle>
                <CardDescription>Monthly leads and conversions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ChartContainer
                    config={{
                      leads: {
                        label: "Leads",
                        color: "hsl(var(--chart-1))",
                      },
                      conversions: {
                        label: "Conversions",
                        color: "hsl(var(--chart-2))",
                      },
                    }}
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={leadData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Legend />
                        <Bar dataKey="leads" fill="var(--color-leads)" />
                        <Bar dataKey="conversions" fill="var(--color-conversions)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Automation Activities</CardTitle>
                <CardDescription>Latest actions taken by the automation system</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-green-100 dark:bg-green-900/20 p-2 rounded-full">
                      <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <p className="font-medium">Weekly user feedback survey generated</p>
                      <p className="text-sm text-muted-foreground">
                        System created a new survey with 7 questions focused on recent feature updates
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">2 hours ago</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-blue-100 dark:bg-blue-900/20 p-2 rounded-full">
                      <Bot className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <p className="font-medium">3 new enhancement suggestions generated</p>
                      <p className="text-sm text-muted-foreground">
                        AI analyzed feedback and suggested improvements to KYC verification, live streaming, and trading
                        features
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">6 hours ago</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-amber-100 dark:bg-amber-900/20 p-2 rounded-full">
                      <TrendingUp className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                    </div>
                    <div>
                      <p className="font-medium">Lead generation campaign launched</p>
                      <p className="text-sm text-muted-foreground">
                        System created and launched a campaign targeting cryptocurrency enthusiasts based on trending
                        topics
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">12 hours ago</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-purple-100 dark:bg-purple-900/20 p-2 rounded-full">
                      <Mail className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div>
                      <p className="font-medium">5 new SEO content pieces published</p>
                      <p className="text-sm text-muted-foreground">
                        System generated and published content related to trending topics in social media and trading
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">1 day ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="feedback">
          <Card>
            <CardHeader>
              <CardTitle>User Feedback Management</CardTitle>
              <CardDescription>Automated survey generation and feedback analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Recent Surveys</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Weekly User Satisfaction Survey</p>
                        <p className="text-sm text-muted-foreground">General feedback on platform experience</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">68% response rate</span>
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Live Streaming Feature Survey</p>
                        <p className="text-sm text-muted-foreground">Feedback on recent streaming updates</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">In progress</span>
                        <Clock className="h-5 w-5 text-amber-600" />
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="font-medium">Trading Platform Feedback</p>
                        <p className="text-sm text-muted-foreground">User experience with trading features</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">52% response rate</span>
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Generate New Survey</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button>General Feedback Survey</Button>
                    <Button>Feature-Specific Survey</Button>
                    <Button>User Satisfaction Survey</Button>
                    <Button>Feature Request Survey</Button>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Feedback Analysis</h3>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div>
                          <p className="font-medium">Top User Concerns</p>
                          <ul className="list-disc pl-5 mt-2 space-y-1">
                            <li>KYC verification process is too slow</li>
                            <li>Occasional lag in live streaming</li>
                            <li>Limited e-book selection in certain languages</li>
                          </ul>
                        </div>

                        <div>
                          <p className="font-medium">Most Requested Features</p>
                          <ul className="list-disc pl-5 mt-2 space-y-1">
                            <li>Enhanced live streaming capabilities</li>
                            <li>More cryptocurrency trading options</li>
                            <li>Improved social networking discovery features</li>
                          </ul>
                        </div>

                        <div>
                          <p className="font-medium">Overall Sentiment</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Progress value={72} className="flex-1" />
                            <span className="text-sm font-medium">72% Positive</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="enhancements">
          <Card>
            <CardHeader>
              <CardTitle>AI Enhancement System</CardTitle>
              <CardDescription>Automated platform improvements based on user feedback</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Recent Enhancement Suggestions</h3>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium">Streamline KYC Verification Process</p>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full">
                            Critical
                          </span>
                          <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                            High Impact
                          </span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        Improve the KYC verification flow to reduce processing time and increase approval rates
                      </p>
                      <div>
                        <p className="text-sm font-medium">Implementation Steps:</p>
                        <ul className="list-disc pl-5 mt-1 text-sm text-muted-foreground">
                          <li>Implement AI-powered document verification</li>
                          <li>Add real-time feedback during submission</li>
                          <li>Create automated approval workflows for low-risk cases</li>
                        </ul>
                      </div>
                      <div className="flex justify-end gap-2 mt-4">
                        <Button variant="outline" size="sm">
                          Reject
                        </Button>
                        <Button size="sm">Implement</Button>
                      </div>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium">Enhance Live Streaming Performance</p>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-1 text-xs font-medium bg-amber-100 text-amber-800 rounded-full">
                            Medium
                          </span>
                          <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                            High Impact
                          </span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        Optimize the live streaming feature to reduce lag and improve quality
                      </p>
                      <div>
                        <p className="text-sm font-medium">Implementation Steps:</p>
                        <ul className="list-disc pl-5 mt-1 text-sm text-muted-foreground">
                          <li>Implement adaptive bitrate streaming</li>
                          <li>Optimize server-side processing</li>
                          <li>Add CDN support for global audiences</li>
                        </ul>
                      </div>
                      <div className="flex justify-end gap-2 mt-4">
                        <Button variant="outline" size="sm">
                          Reject
                        </Button>
                        <Button size="sm">Implement</Button>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Implementation Progress</h3>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium">Expand E-Book Library</p>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                            In Progress
                          </span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        Add more e-books in multiple languages and genres
                      </p>
                      <div className="mt-2">
                        <p className="text-sm font-medium mb-1">Progress: 65%</p>
                        <Progress value={65} />
                      </div>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium">Improve Social Discovery Algorithm</p>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                            Completed
                          </span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        Enhance the algorithm that suggests new connections and content
                      </p>
                      <div className="mt-2">
                        <p className="text-sm font-medium mb-1">Progress: 100%</p>
                        <Progress value={100} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leads">
          <Card>
            <CardHeader>
              <CardTitle>Lead Generation System</CardTitle>
              <CardDescription>Automated lead generation and nurturing</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Lead Generation Performance</h3>
                  <div className="h-80">
                    <ChartContainer
                      config={{
                        leads: {
                          label: "Leads",
                          color: "hsl(var(--chart-1))",
                        },
                        conversions: {
                          label: "Conversions",
                          color: "hsl(var(--chart-2))",
                        },
                      }}
                    >
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={leadData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <ChartTooltip content={<ChartTooltipContent />} />
                          <Legend />
                          <Bar dataKey="leads" fill="var(--color-leads)" />
                          <Bar dataKey="conversions" fill="var(--color-conversions)" />
                        </BarChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Active Lead Campaigns</h3>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium">Cryptocurrency Trading Campaign</p>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                            Active
                          </span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        Targeting cryptocurrency enthusiasts with Access trading platform features
                      </p>
                      <div className="grid grid-cols-3 gap-4 mt-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Leads</p>
                          <p className="text-lg font-medium">450</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Conversions</p>
                          <p className="text-lg font-medium">87</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Rate</p>
                          <p className="text-lg font-medium">19.3%</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium">E-Book Enthusiasts Campaign</p>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                            Active
                          </span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        Targeting book lovers with Access e-book library features
                      </p>
                      <div className="grid grid-cols-3 gap-4 mt-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Leads</p>
                          <p className="text-lg font-medium">320</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Conversions</p>
                          <p className="text-lg font-medium">65</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Rate</p>
                          <p className="text-lg font-medium">20.3%</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Generate New Campaign</h3>
                  <Button>Create AI-Generated Campaign</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

