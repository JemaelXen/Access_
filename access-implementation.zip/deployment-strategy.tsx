import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, AlertCircle } from "lucide-react"

export default function DeploymentStrategy() {
  return (
    <div className="container mx-auto p-4 space-y-8">
      <h1 className="text-3xl font-bold">Continuous Deployment Strategy</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="text-green-500">
                <CheckCircle size={20} />
              </span>
              Feature Flagging
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>Deploy code but control which users see new features. Hide incomplete features behind toggles.</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="text-green-500">
                <CheckCircle size={20} />
              </span>
              Staging Environment
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>Test changes in an environment identical to production before deploying to users.</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="text-green-500">
                <CheckCircle size={20} />
              </span>
              Automated Testing
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>Comprehensive test suite that runs automatically before any code reaches production.</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="text-amber-500">
                <AlertCircle size={20} />
              </span>
              Potential Challenges
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p>• User experience with partially complete features</p>
            <p>• Database schema migrations while live</p>
            <p>• Maintaining backward compatibility</p>
            <p>• Increased complexity in deployment pipeline</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="text-green-500">
                <CheckCircle size={20} />
              </span>
              Solutions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p>• Clear "beta" labeling for new features</p>
            <p>• Zero-downtime database migrations</p>
            <p>• API versioning strategy</p>
            <p>• Automated rollback capabilities</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Phased Deployment Timeline</CardTitle>
          <CardDescription>Releasing features while continuing development</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="bg-purple-100 dark:bg-purple-900 p-3 rounded-full">
                <span className="font-bold">1</span>
              </div>
              <div>
                <h3 className="font-medium">Core Platform (Week 1-4)</h3>
                <p className="text-sm text-muted-foreground">Authentication, profiles, basic social features</p>
              </div>
            </div>

            <div className="flex items-center">
              <div className="h-10 w-0.5 bg-purple-200 dark:bg-purple-800 ml-5"></div>
            </div>

            <div className="flex items-center gap-4">
              <div className="bg-purple-100 dark:bg-purple-900 p-3 rounded-full">
                <span className="font-bold">2</span>
              </div>
              <div>
                <h3 className="font-medium">Content Features (Week 5-8)</h3>
                <p className="text-sm text-muted-foreground">Posts, comments, e-books library</p>
              </div>
            </div>

            <div className="flex items-center">
              <div className="h-10 w-0.5 bg-purple-200 dark:bg-purple-800 ml-5"></div>
            </div>

            <div className="flex items-center gap-4">
              <div className="bg-purple-100 dark:bg-purple-900 p-3 rounded-full">
                <span className="font-bold">3</span>
              </div>
              <div>
                <h3 className="font-medium">Interactive Features (Week 9-12)</h3>
                <p className="text-sm text-muted-foreground">Live streaming, real-time messaging</p>
              </div>
            </div>

            <div className="flex items-center">
              <div className="h-10 w-0.5 bg-purple-200 dark:bg-purple-800 ml-5"></div>
            </div>

            <div className="flex items-center gap-4">
              <div className="bg-purple-100 dark:bg-purple-900 p-3 rounded-full">
                <span className="font-bold">4</span>
              </div>
              <div>
                <h3 className="font-medium">Monetization Features (Week 13-16)</h3>
                <p className="text-sm text-muted-foreground">Trading platform, casino games, premium subscriptions</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

