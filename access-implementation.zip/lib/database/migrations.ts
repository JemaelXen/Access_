// Database migration strategy for zero-downtime updates

import mongoose from "mongoose"

interface Migration {
  version: number
  description: string
  up: () => Promise<void>
  down: () => Promise<void>
}

// Example migration to add a new field to User model
const addKycStatusMigration: Migration = {
  version: 1,
  description: "Add KYC status field to User model",
  up: async () => {
    // This is a non-destructive change that adds a field with a default value
    await mongoose.connection.db
      .collection("users")
      .updateMany({ kycStatus: { $exists: false } }, { $set: { kycStatus: "pending" } })
    console.log("Migration 1: Added kycStatus field to all users")
  },
  down: async () => {
    // Rollback by removing the field
    await mongoose.connection.db.collection("users").updateMany({}, { $unset: { kycStatus: "" } })
    console.log("Migration 1: Removed kycStatus field from all users")
  },
}

// Example migration to add a new collection
const createTransactionsCollectionMigration: Migration = {
  version: 2,
  description: "Create transactions collection",
  up: async () => {
    await mongoose.connection.db.createCollection("transactions")
    console.log("Migration 2: Created transactions collection")
  },
  down: async () => {
    await mongoose.connection.db.dropCollection("transactions")
    console.log("Migration 2: Dropped transactions collection")
  },
}

// Register all migrations in order
const migrations: Migration[] = [
  addKycStatusMigration,
  createTransactionsCollectionMigration,
  // Add new migrations here
]

// Migration runner
export async function runMigrations(targetVersion?: number) {
  try {
    // Create migrations collection if it doesn't exist
    const collections = await mongoose.connection.db.listCollections().toArray()
    if (!collections.some((c) => c.name === "migrations")) {
      await mongoose.connection.db.createCollection("migrations")
      await mongoose.connection.db.collection("migrations").insertOne({
        currentVersion: 0,
        lastRun: new Date(),
      })
    }

    // Get current migration version
    const migrationStatus = await mongoose.connection.db.collection("migrations").findOne({})
    const currentVersion = migrationStatus?.currentVersion || 0

    // Determine target version
    const finalVersion = targetVersion !== undefined ? targetVersion : migrations.length

    if (currentVersion < finalVersion) {
      // Run migrations up
      console.log(`Migrating UP from version ${currentVersion} to ${finalVersion}`)

      for (let i = currentVersion; i < finalVersion; i++) {
        const migration = migrations[i]
        console.log(`Running migration ${migration.version}: ${migration.description}`)
        await migration.up()

        // Update migration version
        await mongoose.connection.db.collection("migrations").updateOne(
          {},
          {
            $set: {
              currentVersion: migration.version,
              lastRun: new Date(),
            },
          },
        )
      }
    } else if (currentVersion > finalVersion) {
      // Run migrations down
      console.log(`Migrating DOWN from version ${currentVersion} to ${finalVersion}`)

      for (let i = currentVersion - 1; i >= finalVersion; i--) {
        const migration = migrations[i]
        console.log(`Rolling back migration ${migration.version}: ${migration.description}`)
        await migration.down()

        // Update migration version
        await mongoose.connection.db.collection("migrations").updateOne(
          {},
          {
            $set: {
              currentVersion: i,
              lastRun: new Date(),
            },
          },
        )
      }
    } else {
      console.log(`Already at version ${currentVersion}, no migrations needed`)
    }

    console.log("Migrations completed successfully")
  } catch (error) {
    console.error("Migration failed:", error)
    throw error
  }
}

