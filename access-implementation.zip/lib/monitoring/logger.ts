// Application logging and monitoring

import type { NextRequest, NextResponse } from "next/server"

// Log levels
export enum LogLevel {
  DEBUG = "debug",
  INFO = "info",
  WARN = "warn",
  ERROR = "error",
}

// Log entry structure
interface LogEntry {
  timestamp: string
  level: LogLevel
  message: string
  context?: Record<string, any>
}

// In a production app, you would send logs to a service like Datadog, New Relic, etc.
// This is a simple implementation for demonstration
export class Logger {
  private static instance: Logger
  private environment: string

  private constructor() {
    this.environment = process.env.NODE_ENV || "development"
  }

  public static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger()
    }
    return Logger.instance
  }

  private formatLog(level: LogLevel, message: string, context?: Record<string, any>): LogEntry {
    return {
      timestamp: new Date().toISOString(),
      level,
      message,
      context: {
        ...context,
        environment: this.environment,
      },
    }
  }

  private sendToLogService(entry: LogEntry): void {
    // In production, send to logging service
    if (this.environment === "production") {
      // Example: send to logging service
      // fetch('https://logging-service.example.com/logs', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(entry),
      // }).catch(err => console.error('Failed to send log:', err));
    }

    // Always log to console for development
    const consoleMethod =
      entry.level === LogLevel.ERROR
        ? console.error
        : entry.level === LogLevel.WARN
          ? console.warn
          : entry.level === LogLevel.INFO
            ? console.info
            : console.debug

    consoleMethod(`[${entry.timestamp}] [${entry.level.toUpperCase()}] ${entry.message}`, entry.context)
  }

  public debug(message: string, context?: Record<string, any>): void {
    const entry = this.formatLog(LogLevel.DEBUG, message, context)
    this.sendToLogService(entry)
  }

  public info(message: string, context?: Record<string, any>): void {
    const entry = this.formatLog(LogLevel.INFO, message, context)
    this.sendToLogService(entry)
  }

  public warn(message: string, context?: Record<string, any>): void {
    const entry = this.formatLog(LogLevel.WARN, message, context)
    this.sendToLogService(entry)
  }

  public error(message: string, error?: Error, context?: Record<string, any>): void {
    const entry = this.formatLog(LogLevel.ERROR, message, {
      ...context,
      error: error
        ? {
            name: error.name,
            message: error.message,
            stack: error.stack,
          }
        : undefined,
    })
    this.sendToLogService(entry)
  }

  // Track API request performance
  public logApiRequest(req: NextRequest, res: NextResponse, startTime: number): void {
    const duration = Date.now() - startTime
    const status = res.status
    const method = req.method
    const url = req.url

    this.info(`API Request: ${method} ${url}`, {
      duration,
      status,
      method,
      url,
    })

    // Track slow requests
    if (duration > 1000) {
      this.warn(`Slow API Request: ${method} ${url}`, {
        duration,
        status,
        method,
        url,
      })
    }
  }
}

// Export singleton instance
export const logger = Logger.getInstance()

