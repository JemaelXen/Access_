// Simple feature flag system

type FeatureFlag = {
  name: string
  description: string
  enabled: boolean
  enabledForUsers?: string[] // User IDs for specific user targeting
  rolloutPercentage?: number // For gradual rollout (0-100)
}

// Feature flags configuration
const featureFlags: Record<string, FeatureFlag> = {
  LIVE_STREAMING: {
    name: "Live Streaming",
    description: "Enable live streaming functionality",
    enabled: false,
    rolloutPercentage: 0, // 0% rollout initially
  },
  TRADING_PLATFORM: {
    name: "Trading Platform",
    description: "Enable trading platform functionality",
    enabled: false,
  },
  CASINO_GAMES: {
    name: "Casino Games",
    description: "Enable casino games functionality",
    enabled: false,
  },
  EBOOK_LIBRARY: {
    name: "E-Book Library",
    description: "Enable e-book library functionality",
    enabled: true,
    rolloutPercentage: 50, // 50% of users will see this feature
  },
  DARK_MODE: {
    name: "Dark Mode",
    description: "Enable dark mode theme option",
    enabled: true, // Enabled for everyone
  },
}

// Check if a feature is enabled for a specific user
export function isFeatureEnabled(featureKey: string, userId?: string): boolean {
  const feature = featureFlags[featureKey]

  if (!feature) {
    return false // Feature doesn't exist
  }

  if (!feature.enabled) {
    return false // Feature is globally disabled
  }

  // Check if enabled for specific users
  if (userId && feature.enabledForUsers && feature.enabledForUsers.includes(userId)) {
    return true
  }

  // Check rollout percentage
  if (feature.rolloutPercentage !== undefined) {
    if (feature.rolloutPercentage === 100) {
      return true // Available to everyone
    }

    if (feature.rolloutPercentage === 0) {
      return false // Available to no one
    }

    if (userId) {
      // Deterministic random number based on user ID for consistent experience
      const hash = userId.split("").reduce((acc, char) => {
        return acc + char.charCodeAt(0)
      }, 0)

      // Get a number between 0-100
      const userValue = hash % 100

      // If user's value is within the rollout percentage, enable the feature
      return userValue < feature.rolloutPercentage
    }

    // If no user ID, use random chance based on percentage
    return Math.random() * 100 < feature.rolloutPercentage
  }

  return true // Feature is enabled with no restrictions
}

// Admin function to update feature flags
export async function updateFeatureFlag(featureKey: string, updates: Partial<FeatureFlag>): Promise<boolean> {
  try {
    // In a real implementation, this would call an API to update the flags
    // For now, we'll just update the local object
    if (featureFlags[featureKey]) {
      featureFlags[featureKey] = {
        ...featureFlags[featureKey],
        ...updates,
      }
      return true
    }
    return false
  } catch (error) {
    console.error("Error updating feature flag:", error)
    return false
  }
}

