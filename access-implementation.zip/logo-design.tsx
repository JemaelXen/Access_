"use client"

import { useState } from "react"
import { motion } from "framer-motion"

export default function AccessLogo() {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div className="flex flex-col items-center justify-center p-8 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 rounded-xl">
      <div className="relative" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
        <motion.div
          className="flex items-center justify-center"
          animate={{ scale: isHovered ? 1.05 : 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="relative">
            {/* Main circle */}
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center shadow-lg">
              {/* Inner circle with cutout */}
              <div className="w-20 h-20 rounded-full bg-white dark:bg-gray-900 relative overflow-hidden">
                {/* Cutout section creating the "A" shape */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-10 h-full bg-purple-600 clip-path-triangle"></div>
              </div>
            </div>

            {/* Orbit effect */}
            <motion.div
              className="absolute top-0 left-0 w-full h-full rounded-full border-2 border-purple-300 dark:border-purple-800 opacity-70"
              animate={{ rotate: isHovered ? 360 : 0 }}
              transition={{ duration: 10, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
            />

            {/* Connection dots */}
            <motion.div
              className="absolute top-2 right-2 w-4 h-4 rounded-full bg-indigo-400 dark:bg-indigo-500"
              animate={{ y: isHovered ? -5 : 0, x: isHovered ? 5 : 0 }}
              transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
            />
            <motion.div
              className="absolute bottom-4 left-0 w-3 h-3 rounded-full bg-purple-400 dark:bg-purple-500"
              animate={{ y: isHovered ? 5 : 0, x: isHovered ? -3 : 0 }}
              transition={{ duration: 0.8, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", delay: 0.2 }}
            />
            <motion.div
              className="absolute bottom-2 right-4 w-2 h-2 rounded-full bg-blue-400 dark:bg-blue-500"
              animate={{ y: isHovered ? 3 : 0, x: isHovered ? 3 : 0 }}
              transition={{ duration: 1.2, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse", delay: 0.4 }}
            />
          </div>
        </motion.div>

        <motion.div className="mt-6 text-center" animate={{ y: isHovered ? -2 : 0 }} transition={{ duration: 0.3 }}>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-indigo-600 text-transparent bg-clip-text">
            ACCESS
          </h1>
          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">Connect • Share • Trade</p>
        </motion.div>
      </div>

      <style jsx>{`
        .clip-path-triangle {
          clip-path: polygon(0% 0%, 100% 0%, 50% 100%);
        }
      `}</style>
    </div>
  )
}

